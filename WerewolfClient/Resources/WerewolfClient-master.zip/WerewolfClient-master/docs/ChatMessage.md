# WerewolfAPI.Model.ChatMessage
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **long?** |  | [optional] 
**Player** | [**Player**](Player.md) |  | [optional] 
**Message** | **string** |  | 
**Channel** | **string** | Chat channel | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

